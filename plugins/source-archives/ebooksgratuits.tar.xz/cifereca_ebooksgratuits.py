from __future__ import annotations
import hashlib, html, re, tempfile, zipfile
from pathlib import Path
from urllib.parse import urljoin, quote_plus, urlsplit
import httpx
from cifereca.plugin_api import Account, ItemDetail, SearchResult, ProviderCapabilities, ProviderDescriptor, ProviderError, ProviderPlugin, ProviderSession

BASE='https://www.ebooksgratuits.com/'
DESCRIPTOR=ProviderDescriptor(id='ebooksgratuits',display_name='Ebooks libres et gratuits',description='Catalogue public francophone et téléchargement EPUB.',state='ready',capabilities=ProviderCapabilities(search=True,holdings=True,direct_download=True),homepage=BASE,notes=('Source publique sans authentification.',))
class Parser:
    rx=re.compile(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',re.I|re.S)
    def rows(self,text):
        out=[]
        for href,label in self.rx.findall(text):
            plain=re.sub('<[^>]+>',' ',html.unescape(label)); plain=' '.join(plain.split())
            if not plain or not re.search(r'epub',plain,re.I) or not href.lower().endswith(('.php','.epub')): continue
            if 'newsendbook' in href.lower():
                ident=re.search(r'(?:id|book)=([0-9]+)',href)
                if not ident: continue
                out.append({'id':ident.group(1),'title':'','epub':urljoin(BASE,href),'detail':''})
            elif 'details.php' in href.lower(): out.append({'id':href,'title':plain,'detail':urljoin(BASE,href)})
        # Enrich EPUB links with nearest details/title in the page by stable sequence.
        return out
class EbooksSession(ProviderSession):
    def __init__(self,*,config,diagnostics,**kw):
        super().__init__(descriptor=DESCRIPTOR,**kw); self.client=httpx.Client(timeout=float(self.options.get('timeout_seconds',30)),follow_redirects=True,trust_env=False,headers={'User-Agent':'Cifereca-EbooksGratuits/0.1.0','Accept-Language':'fr-FR,fr;q=0.9'}); self.maximum=int(self.options.get('max_download_bytes',100*1024*1024)); self.diagnostics=diagnostics
    def connect(self):
        self.connected=True; self._accounts=[Account(display_name='Catalogue public',unique_id='ebooksgratuits',provider_id='ebooksgratuits',credential_id=self.credential_id,provider_label=self.descriptor.display_name,is_primary=True)]; return self.accounts
    def close(self): self.client.close(); self.connected=False; self._accounts=[]
    def _fetch(self,url):
        try:r=self.client.get(url); r.raise_for_status(); return r
        except httpx.HTTPError as e: raise ProviderError('Ebooks libres et gratuits : réseau indisponible') from e
    def search(self,query,scope='all',page=0,field='all'):
        if not self.connected: raise ProviderError('Ebooks libres et gratuits : connecter le catalogue')
        if query:
            try:
                r=self.client.post(BASE+'ebooks.php',data={'titre':query,'offset':'0','Submit':'Rechercher'})
                r.raise_for_status()
            except httpx.HTTPError as e: raise ProviderError('Ebooks libres et gratuits : recherche indisponible') from e
        else:
            r=self._fetch(BASE+'ebooks.php')
        text=r.text
        cards=re.findall(r'<li[^>]*>(.*?)</li>',text,re.I|re.S)
        out=[]
        for card in cards:
            m=re.search(r'href=["\']([^"\']*details\.php[^"\']*)["\'][^>]*>(.*?)</a>',card,re.I|re.S)
            if not m: continue
            detail=urljoin(BASE,m.group(1)); tm=re.search(r'class=["\']listeb["\'][^>]*>(.*?)</span>',card,re.I|re.S); title=' '.join(re.sub('<[^>]+>',' ',html.unescape(tm.group(1) if tm else m.group(2))).split()); am=re.search(r'class=["\']auteur["\'][^>]*>(.*?)</',card,re.I|re.S); author=' '.join(re.sub('<[^>]+>',' ',html.unescape(am.group(1))).split()) if am else None
            e=re.search(r'href=["\']([^"\']*newsendbook\.php\?[^"\']*format=epub[^"\']*)["\'][^>]*>[^<]*ePub',card,re.I)
            if not e: continue
            epub=urljoin(BASE,e.group(1)); rid=hashlib.sha256(detail.encode()).hexdigest()[:24]
            out.append(SearchResult(id='ebooksgratuits:'+rid,record_id=rid,docbase='EBOOKSGRATUITS',medium='digital',title=title,author=author,type='Livre numérique',format='EPUB',publisher='Ebooks libres et gratuits',published_at=None,description=None,thumbnail_url=None,friendly_url=detail,scenario='EBOOKSGRATUITS_CATALOG',source_provider='ebooksgratuits',source_credential=self.credential_id,download_url=epub,content_type='ebook',source_collection='public',owned=False,downloadable=True,metadata={'license_note':'Vérifier les droits selon le pays'}))
        return out[int(page)*50:int(page)*50+50]
    def holdings(self,item,search_terms=''): return ItemDetail(record_id=item.record_id,docbase='EBOOKSGRATUITS',title=item.title,author=item.author,type=item.type,year=None,thumbnail_url=item.thumbnail_url,availability_status='available',availability_label='Téléchargement public EPUB',holdings=[],source_provider=self.provider_id,source_credential=self.credential_id)
    def download_direct(self,item,target_dir):
        if item.source_provider!=self.provider_id or not item.download_url: raise ProviderError('Ebooks libres et gratuits : offre inconnue')
        r=self._fetch(item.download_url)
        if len(r.content)>self.maximum: raise ProviderError('Ebooks libres et gratuits : fichier trop volumineux')
        d=Path(target_dir); d.mkdir(parents=True,exist_ok=True); dest=d/(re.sub(r'[^\w .-]','_',item.title).strip() or item.record_id)+'.epub'; part=Path(tempfile.mktemp(prefix='.eg-',dir=d))
        part.write_bytes(r.content)
        try:
            with zipfile.ZipFile(part) as z:
                if z.read('mimetype')!=b'application/epub+zip': raise ValueError
            part.replace(dest)
        except (Exception,): part.unlink(missing_ok=True); raise ProviderError('Ebooks libres et gratuits : EPUB invalide')
        return dest,item.friendly_url or BASE
class Plugin(ProviderPlugin):
    descriptor=DESCRIPTOR
    def __init__(self): self._sessions=[]; self.context=None
    def activate(self,context): self.context=context; return self
    def deactivate(self):
        for session in self._sessions:
            try: session.close()
            except Exception: pass
        self._sessions.clear(); self.context=None
    def create_session(self,*,credential_id,label,credentials,options,config,storage,diagnostics):
        session=EbooksSession(credential_id=credential_id,label=label,credentials=credentials,options=options,config=config,diagnostics=diagnostics); self._sessions.append(session); return session
PLUGIN=Plugin()
