"""Public loan reconciliation and conservative Kobo duplicate protection."""
import ast, unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import Mock, patch
from cifereca.plugin_api import AttentionRequired
from cifereca.locking import LockBusyError
from . import test_core_0919 as old
from . import test_kobo_vault as kobo

class Inventory(unittest.TestCase):
 setUp=old.Core0919.setUp
 tearDown=old.Core0919.tearDown
 book=old.Core0919.book
 initial=old.Core0919.initial
 def fixture(self, **loan_values):
  path=Path(self.storage.acquisition_get(self.aid)['metadata']['path']) if hasattr(self,'aid') else self.initial();status=self.service.adept_return_status_for_loan(self.loan);self.aid=status['acquisition_id']
  row=self.storage.acquisition_get(self.aid);row['metadata']['adept_binding'].update(adept_loan_id=None,return_available=False);self.storage.acquisition_put(row)
  loan={'id':'registry-id','expired':False,'returned':False,'token_present':True,'local_book':str(path),**loan_values}
  self.runtime=NS(capabilities=Mock(return_value={'capabilities':{'adept':{'loan_return':True}}}),loan_inventories=Mock(return_value={'complete':True,'profiles':[{'profile':'hb','loans':[loan]}],'errors':[]}),loans=Mock(return_value={'loans':[{**loan,'returned':True}]}))
  self.service._kobo_adapter=Mock(return_value=self.runtime)
  self.service.__dict__.pop('_adept_return_capability',None)
  return path,loan
 def reconcile(self,**kw):return self.service.reconcile_adept_acquisition(self.aid,**kw)
 def binding(self):return self.storage.acquisition_get(self.aid)['metadata']['adept_binding']
 def test_missing_id_restored_without_download(self):
  path,loan=self.fixture();count=self.service.execute_acquisition_request.call_count;before=path.read_bytes()
  self.assertEqual(self.reconcile()['status'],'resolved');self.assertEqual(self.binding()['adept_loan_id'],'registry-id');self.assertTrue(self.binding()['return_available'])
  self.assertEqual(path.read_bytes(),before);self.assertEqual(self.service.execute_acquisition_request.call_count,count)
 def test_origin_id_resolves_renamed_profile_not_identity_current_profile(self):
  self.fixture();self.service.kobo_profiles.return_value=[{'profile_id':'stable-profile','name':'Héloïse'},{'profile_id':'different','name':'Hugues'}]
  self.storage.adept_profile_binding_set('identity','default','different')
  self.runtime.loan_inventories.return_value['profiles'][0]['profile']='Héloïse'
  self.reconcile();self.runtime.loan_inventories.assert_called_once_with(['Héloïse']);self.assertEqual(self.binding()['adept_profile_id'],'stable-profile')
 def test_identity_profile_used_only_when_origin_absent(self):
  self.fixture();row=self.storage.acquisition_get(self.aid);row['metadata']['adept_binding']['adept_profile_id']=None;self.storage.acquisition_put(row)
  self.reconcile();self.runtime.loan_inventories.assert_called_once_with(['hb'])
 def test_no_binding_never_uses_hb_default(self):
  self.fixture();row=self.storage.acquisition_get(self.aid);row['metadata']['adept_binding']['adept_profile_id']=None;self.storage.acquisition_put(row)
  self.storage.adept_profile_binding_set('identity','default','')
  self.assertEqual(self.reconcile()['status'],'profile_missing');self.runtime.loan_inventories.assert_not_called()
 def test_duplicate_exact_paths_are_ambiguous(self):
  self.fixture();rows=self.runtime.loan_inventories.return_value['profiles'][0]['loans'];rows.append(dict(rows[0]))
  self.assertEqual(self.reconcile()['status'],'ambiguous');self.assertIsNone(self.binding()['adept_loan_id'])
 def test_partial_inventory_cannot_establish_uniqueness(self):
  self.fixture();self.runtime.loan_inventories.return_value['complete']=False
  self.assertEqual(self.reconcile()['status'],'inventory_error');self.assertFalse(self.binding()['return_available'])
 def test_matching_title_with_old_migrated_path_is_not_proof(self):
  self.fixture(local_book='/previous/Livre.epub',title='Livre')
  self.assertEqual(self.reconcile()['status'],'unresolved');self.assertIsNone(self.binding()['adept_loan_id'])
 def test_conflicting_registry_id_never_overwrites_original(self):
  self.fixture();row=self.storage.acquisition_get(self.aid);row['metadata']['adept_binding']['adept_loan_id']='original';self.storage.acquisition_put(row)
  self.assertEqual(self.reconcile()['status'],'binding_conflict');self.assertEqual(self.binding()['adept_loan_id'],'original')
 def test_multiple_explicit_profiles_keep_namespace_and_ambiguity(self):
  path,loan=self.fixture();row=self.storage.acquisition_get(self.aid);row['metadata']['adept_binding']['adept_profile_id']=None;self.storage.acquisition_put(row)
  self.service.kobo_profiles.return_value.append({'profile_id':'other','name':'Hugues'})
  self.runtime.loan_inventories.return_value['profiles'].append({'profile':'Hugues','loans':[dict(loan)]})
  self.assertEqual(self.reconcile(profile_references=['stable-profile','other'])['status'],'ambiguous')
  self.runtime.loan_inventories.assert_called_once_with(['hb','Hugues'])
 def test_read_allowed_when_return_capability_false(self):
  self.fixture();self.runtime.capabilities.return_value['capabilities']['adept']['loan_return']=False
  self.assertEqual(self.reconcile()['status'],'resolved');self.assertFalse(self.service.adept_return_status_for_loan(self.loan)['return_available'])
  self.runtime.loans.return_value={'loans':[self.runtime.loan_inventories.return_value['profiles'][0]['loans'][0]]}
  with self.assertRaises(AttentionRequired):self.service.return_adept_acquisition(self.aid)
 def test_expired_and_token_missing_disable_return(self):
  for values,state in [({'expired':True},'expired'),({'token_present':False},'token_missing')]:
   with self.subTest(values=values):
    self.fixture(**values);self.reconcile();status=self.service.adept_return_status_for_loan(self.loan)
    self.assertEqual(status['status'],state);self.assertFalse(status['return_available'])
 def test_old_returned_state_is_revalidated_by_registry(self):
  self.fixture(returned=True);self.reconcile();self.assertEqual(self.binding()['loan_state'],'returned')
  self.runtime.loan_inventories.return_value['profiles'][0]['loans'][0]['returned']=False
  self.reconcile();self.assertEqual(self.binding()['loan_state'],'active');self.assertTrue(self.binding()['return_available'])
 def test_disappeared_inventory_keeps_historical_binding_and_file(self):
  path,loan=self.fixture();self.reconcile();self.runtime.loan_inventories.return_value['profiles'][0]['loans']=[]
  self.reconcile();self.assertEqual(self.binding()['adept_loan_id'],'registry-id');self.assertTrue(path.exists());self.assertFalse(self.binding()['return_available'])
 def test_missing_file_never_queries_inventory(self):
  path,loan=self.fixture();path.unlink();self.assertEqual(self.reconcile()['status'],'artifact_missing');self.runtime.loan_inventories.assert_not_called()
 def test_lock_busy_prevents_query(self):
  self.fixture()
  with patch('cifereca.services.InterProcessLock') as lock:
   lock.return_value.__enter__.side_effect=LockBusyError('busy')
   with self.assertRaises(AttentionRequired):self.reconcile()
  self.runtime.loan_inventories.assert_not_called()
 def test_batch_reuses_inventory_per_profile(self):
  self.fixture();row=self.storage.acquisition_get(self.aid);self.storage.acquisition_put({**row,'acquisition_id':'other'})
  result=self.service._reconcile_identity_adept_inventory('default');self.assertEqual(result['resolved'],2);self.runtime.loan_inventories.assert_called_once()
 def prepare_return(self):
  path,loan=self.fixture();self.reconcile()
  self.service.execute_drm_mutation=Mock(return_value={'ok':True,'metadata':{'runtime_result':{'ok':True,'operation':'loan_return','profile':'hb','loan_id':'registry-id'}}})
  self.runtime.loans.side_effect=lambda name:{'loans':[{**loan,'returned':bool(self.service.execute_drm_mutation.call_count),'token_present':not bool(self.service.execute_drm_mutation.call_count)}]}
  return path
 def test_confirmed_return_refreshes_public_inventory_keeps_artifact(self):
  path=self.prepare_return();before=path.read_bytes();result=self.service.return_adept_acquisition(self.aid)
  self.assertEqual(result['verification'],'confirmed');self.assertEqual(path.read_bytes(),before)
  self.service.return_adept_acquisition(self.aid);self.service.execute_drm_mutation.assert_called_once()
 def test_return_refresh_failure_withholds_success(self):
  self.prepare_return();self.runtime.loans.side_effect=RuntimeError('offline')
  with self.assertRaises(AttentionRequired):self.service.return_adept_acquisition(self.aid)
  self.assertEqual(self.binding()['loan_state'],'active');self.service.execute_drm_mutation.assert_not_called()
 def test_return_not_verified_is_explicit(self):
  self.prepare_return();self.runtime.loans.side_effect=lambda name:{'loans':[]}
  with self.assertRaises(AttentionRequired):self.service.return_adept_acquisition(self.aid)
  self.assertEqual(self.binding()['loan_state'],'active')
 def test_unknown_acquisition_rejected(self):
  with self.assertRaises(AttentionRequired):self.service.reconcile_adept_acquisition('unknown')

class KoboGuard(unittest.TestCase):
 def setUp(self):
  import tempfile
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.service,self.session=kobo._library_service(self.root);self.fake=kobo.FakeAdept();self.service._kobo_adapter=lambda:self.fake
 def tearDown(self):self.service.close();self.tmp.cleanup()
 def imported(self):
  path=self.root/'EBooks/import.epub';old.Core0919.book(self,path);self.service.catalog_index_path(path,identity_id='default',provider_id='local');return path
 def test_unlinked_import_blocks_batch_without_download(self):
  path=self.imported();before=path.read_bytes();events=[];result=self.service.sync_kobo_backup(progress=events.append)
  self.assertEqual(result['downloaded'],0);self.assertEqual(result['attempted'],0);self.assertEqual(result['attention_required'],1);self.assertEqual(path.read_bytes(),before)
  self.assertEqual(self.service.storage.backup_get('kobo','vault-1','book-1')['attention_code'],'unlinked_local_books')
 def test_explicit_permission_allows_acquisition_without_overwriting_import(self):
  path=self.imported();before=path.read_bytes();self.service.config.set('kobo_backup.allow_unlinked_acquisition',True)
  result=self.service.sync_kobo_backup();self.assertEqual(result['downloaded'],1);self.assertEqual(path.read_bytes(),before)
 def test_other_identity_does_not_block_current_account(self):
  path=self.root/'other.epub';old.Core0919.book(self,path);self.service.catalog_index_path(path,identity_id='other',provider_id='local')
  self.assertEqual(self.service.kobo_unlinked_local_count('default'),0);self.assertEqual(self.service.sync_kobo_backup()['downloaded'],1)
 def test_missing_local_file_does_not_block(self):
  self.imported().unlink();self.assertEqual(self.service.sync_kobo_backup()['downloaded'],1)
 def test_linked_complete_same_revision_still_skips_with_other_unlinked_file(self):
  self.assertEqual(self.service.sync_kobo_backup()['downloaded'],1);self.imported()
  result=self.service.sync_kobo_backup();self.assertEqual(result['downloaded'],0);self.assertEqual(result['unchanged'],1)

 def test_unindexed_import_is_scanned_before_guard(self):
  path=self.root/'EBooks/import.epub';old.Core0919.book(self,path)
  result=self.service.sync_kobo_backup();self.assertEqual(result['downloaded'],0);self.assertEqual(result['attention_required'],1)

class UI(unittest.TestCase):
 extract=old.Core0919.extract
 def test_reconcile_ui_runs_on_worker_and_refreshes_detail(self):
  from cifereca.task_queue import TaskPriority
  w=NS(service=NS(reconcile_adept_acquisition=Mock(return_value={'status':'resolved'})),runner=Mock(),loan_page=NS(detail=NS(show_loan=Mock())),toast=Mock(),show_error=Mock())
  loan=object();control=object();self.extract('reconcile_adept_from_detail')(w,'acquisition',loan,control)
  args=w.runner.submit.call_args.args;self.assertEqual(w.runner.submit.call_args.kwargs['kind'],'adept-inventory')
  args[2](args[1]());w.service.reconcile_adept_acquisition.assert_called_once_with('acquisition');w.loan_page.detail.show_loan.assert_called_once_with(loan)
 def test_unconfirmed_return_message_never_claims_confirmation(self):
  w=NS(service=NS(return_adept_acquisition=Mock(return_value={'ok':True,'verification':'refresh_failed'})),runner=Mock(),refresh_library=Mock(),toast=Mock(),show_error=Mock())
  self.extract('return_adept_from_detail')(w,'acquisition',object());args=w.runner.submit.call_args.args;args[2](args[1]())
  self.assertIn('non confirmé',w.toast.call_args.args[0]);self.assertNotIn('jeton absent',w.toast.call_args.args[0]);w.show_error.assert_not_called()
